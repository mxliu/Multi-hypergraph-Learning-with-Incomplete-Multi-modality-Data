function [F W] = HGL(H,W,Y,mPara)
%% Hypergraph learning with hyperedge weight learning


%% parameter setting
nMod = size(H,1); % number of modalities or distance matrices
nObject = size(H,1); % number of objects in the learning process
nEdge = size(H,2); % number of hyperedges
IsWeight = mPara.IsWeight;% whether learn hyperedge weight
nIter = mPara.nIter;
lambda = mPara.lambda;
mu = mPara.mu;
%%%%%%%%%%%%%%%%%%

%% Initialization
F = zeros(nObject,1);
%%%%%%%%%%%%%%%%%%

if IsWeight == 0 % if weight learning is not required
   DV = eye(nObject);
   for iObject = 1:nObject
      DV(iObject,iObject) = sum(H(iObject,:).*diag(W)'); 
   end
   DE = eye(nEdge);
   for iEdge = 1:nEdge
       DE(iEdge,iEdge)=sum(H(:,iEdge));
   end
   DV2 = DV^(-0.5);
   INVDE = inv(DE);
   Theta = DV2*H*W*INVDE*H'*DV2;
    
    L2 = eye(nObject)-1/(1+lambda)*Theta;
    F = (lambda/(1+lambda))*L2\Y;
elseif IsWeight == 1% if weight learning is required
    flag = 1;
    for iIter = 1:nIter
        if flag == 1          
                %% update F
               Theta = zeros(nObject);   
               DV = eye(nObject);
               for iObject = 1:nObject
                  DV(iObject,iObject) = sum(H(iObject,:).*W'); 
               end
               DE = eye(nEdge);
               for iEdge = 1:nEdge
                   DE(iEdge,iEdge)=sum(H(:,iEdge));
               end
               DV2 = DV^(-0.5);
               INVDE = inv(DE);
               Theta = DV2*H*diag(W)*INVDE*H'*DV2;
                
                L2 = eye(nObject)-1/(1+lambda)*Theta;
                F = (lambda/(1+lambda))*L2\Y;

                %% save current F and the previous F
                if iIter > 1
                    mF{1,1} = mF{2,1};
                    mF{2,1} = F;
                else
                    mF{2,1} = F;
                end
                
                %% update hyperedge weight W
                B = 2*mu*eye(nEdge);
                Tau0=DV2*H;
                C = zeros(nEdge,1);
                for iEdge = 1:nEdge  
                    C(iEdge) = -INVDE(iEdge,iEdge)*trace(sum((F'*Tau0(:,iEdge)).^2));
                end
                Aeq = H;
                beq = diag(DV);
                lb = zeros(nEdge, 1);
                options = optimset('LargeScale', 'off', 'MaxIter', 10000, 'Display', 'off');
                [W, tmpobj]= quadprog(B,C,[],[],Aeq,beq,lb,[],[],options);
                
                 
%                 Gamma = DV2* H;
%                  
%                  % term3 is different size with term1 and term2
%                  term1 = 1/nEdge;
%                  term2 = -(F'*Gamma*INVDE*Gamma'*F)/(2*nEdge*mu);
%                  term3 = diag(((F'*Gamma).^2 * INVDE))/(2*mu);
%                  %     W = (term1+term2)*eye(n_e)+term3;
%                  newW = (term1+term2)*diag((ones(nEdge,1))) + term3;                 
%                  newW(W<0) = 0;
%                  W=diag(newW);
                
                %% calculate the cost function
                laplacian = F(:,1)' * (eye(nObject) - Theta) * F(:,1);
                exploss =  lambda * (norm(F(:,1) - Y(:,1)));
                costValue(iIter,1) = laplacian + exploss + mu*sum(W.*W);
                
                if iIter > 1
                    disp(['Iteration = ' num2str(iIter) ' The cost value is ' num2str(costValue(iIter,1)) ' The cost value is reduced by ' num2str(costValue(iIter) - costValue(iIter-1))]);
                     if costValue(iIter) - costValue(iIter-1) > -0.00001 % if the cost value does not decrease again, stop the iteration
                         flag = 0;
                         disp(['Iteration stops after ' num2str(iIter-1) ' round.']);
                         F = mF{1,1};
%                          bar(W);
                     end
                 else                     
                     disp(['Iteration = ' num2str(iIter) ' The cost value is ' num2str(costValue(iIter,1))]);
                 end
        end       
    end
end