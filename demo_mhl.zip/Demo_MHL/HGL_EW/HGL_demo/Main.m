clear all;
clc;

%% simulation distance matrices
mDist{1,1} = rand(100,100);
mDist{2,1} = rand(100,100);
%%%%%%%%%%%%%%%%

%% parameter settings
mPara.mDist = mDist;
% n*1 cell, the distance matrix for all samples

mPara.IS_ProH = 1;
% IS_ProH is to determine whether the hypergraph incidence matrix is constructed probabilistically
% 1: the entry of H is a probability,    2: the entry of H is 1 or 0.
% Generally, IS_ProH = 1 works better.

mPara.mProb = 0.05;
% The parameter for probabilistic incidence matrix (exp(-d^2/sigma^2), sigma = mPro.aveDist)
% It is usually set as 0.05 or 0.1

mPara.GraphType = 1;
% The neighbor selection method
% 1: star expansion using mStarExp   2: distance-based using mRatio

mPara.mStarExp = 10; 
% The number of star expansion
% It can be set as 5, 10, 20, or other numbers

mPara.mRatio = 0.1;
% The ratio of average distance to select neighbor
% It is set as 0.1 or 1. We need to check the incidence matrix H to determine it

mPara.IsWeight = 1;
% Whether learn the hypergraph weight during learning process
% 1: learn  0:no-learn

mPara.lambda = 10;
% The parameter on empirical loss in hypergraph learning
% lambda may range from 10e-2 to 10e4

mPara.mu = 0.01;
% The parameter on the hyperedge weight in hypergraph learning
% mu may range from 10e-2 to 10e4

mPara.nIter = 100;
% The maximal iteration times for learning
% The iteration may stop in no more than 20 rounds.

%% Initialize Y
nObject = size(mDist{1,1},1); % number of objects in the learning process
Y = zeros(nObject,1);
Y(1,1) = 1;% the query is set as 1
%%%%%%%%%%%%%%%%%
  
%% The main procedures
[H W] = HGConstruction(mPara);
[F W2] = HGL(H,W,Y,mPara);
% F is the to-be-learned relevance vector
aa=1;