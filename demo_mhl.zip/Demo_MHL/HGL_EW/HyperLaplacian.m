function [L2] = HyperLaplacian(H,W,mPara)
%% Hypergraph Laplacain Matrix

%% parameter setting
%nMod = size(H,1); % number of modalities or distance matrices
nObject = size(H,1); % number of objects in the learning process
nEdge = size(H,2); % number of hyperedges
IsWeight =  mPara.IsWeight;% whether learn hyperedge weight
nIter = mPara.nIter;
lambda = mPara.lambda;
%mu = mPara.mu;
%%%%%%%%%%%%%%%%%%

%%%%%%%%%%%%%%%%%%

if IsWeight == 0 % if weight learning is not required
   DV = eye(nObject);
   for iObject = 1:nObject
      DV(iObject,iObject) = sum(H(iObject,:).*W'); 
   end
   DE = eye(nEdge);
   for iEdge = 1:nEdge
       DE(iEdge,iEdge)=sum(H(:,iEdge));
   end
   DV2 = DV^(-0.5);
   INVDE = inv(DE);
   Theta = DV2*H*W*INVDE*H'*DV2;
    
    L2 = eye(nObject)-1/(1+lambda)*Theta;
%    F = (lambda/(1+lambda))*L2\Y;
elseif IsWeight == 1% if weight learning is required
    flag = 1;
    for iIter = 1:nIter
        if flag == 1          
                %% update F
               Theta = zeros(nObject);   
               DV = eye(nObject);
               for iObject = 1:nObject
                  DV(iObject,iObject) = sum(H(iObject,:).*W'); 
               end
               DE = eye(nEdge);
               for iEdge = 1:nEdge
                   DE(iEdge,iEdge)=sum(H(:,iEdge));
               end
               DV2 = DV^(-0.5);
               INVDE = inv(DE);
               Theta = DV2*H*diag(W)*INVDE*H'*DV2;
                
                L2 = eye(nObject)-1/(1+lambda)*Theta;
% 
        end       
    end
end