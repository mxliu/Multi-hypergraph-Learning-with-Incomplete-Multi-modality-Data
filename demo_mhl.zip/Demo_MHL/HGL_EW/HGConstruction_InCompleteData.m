function [H W] = HGConstruction_InCompleteData(mPara)
%% this function is to construct one hypergraph using different distance matrices

%%parameter setting
mDist = mPara.mDist;
IS_ProH = mPara.IS_ProH;
mStarExp = mPara.mStarExp; % The number of star expansion
mRatio = mPara.mRatio;
mProb = mPara.mProb;
nMod = size(mDist,1); % The number of modalities or distance matrices
nObject = size(mDist{1,1},1); % The number of objects in the learning process
% nEdge = nObject*nMod; % The number of hyperedges
nEdge = nObject*nMod*size(mStarExp,2); % The number of hyperedges
% It is noted that the number of edges nEdge is determined by the way of hyperedge generation.
%%%%%%%%%%%%%%%%%

H = zeros(nObject,nEdge); % the incidence matrices for all modalities
W = ones(nEdge,1);
iEdge = 0;
for iMod = 1:nMod
    distM = mDist{iMod,1}; % the distance marix in current modality
    aveDist =mean(mean(distM));% the mean distancein current modaltiy
  
  for neighbor=1:size(mStarExp,2)  
    for iObject = 1:nObject
%          if ~isnan(distM(nObject,nObject))
                iEdge = iEdge + 1;              
                vDist = distM(:,iObject)';
                [values orders] = sort(vDist,'ascend');
                if mPara.GraphType == 1% star expansion
                        orders2 = orders(1:mStarExp(1,neighbor));
                        if isempty(find(orders2==iObject))
                            values(mStarExp(1,neighbor))=0;
                            orders(mStarExp(1,neighbor))=iObject;
                        end
                        for iNeighbor = 1:mStarExp
                                if IS_ProH == 0 % if it is not pro H
                                    H(orders(iNeighbor),iEdge) = 1;
                                else
                                    H(orders(iNeighbor),iEdge)  = exp(-values(iNeighbor)^2/(mProb*aveDist)^2);
                                end
                        end
                elseif mPara.GraphType == 2% distance-based
                        threshold = mRatio*aveDist; % the threshold for distance-based hyperedge construction
                        for iNeighbor = 1:nObject
                                if vDist(iNeighbor) < threshold
                                       if IS_ProH == 0 % if it is not pro H
                                                H(iNeighbor,iEdge) = 1;
                                       else
                                                H(iNeighbor,iEdge)  = exp(-vDist(iNeighbor)^2/(mProb*aveDist)^2);
                                       end
                                end
                        end
                end
                
%          end % end for incomplete Data
    end  % for iObject
  end % for neighbors
end