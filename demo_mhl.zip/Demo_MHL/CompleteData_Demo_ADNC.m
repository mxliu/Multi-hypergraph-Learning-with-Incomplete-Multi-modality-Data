function CompleteData_Demo_ADNC
%% Use Complete multi-modal data to construct hypergraphs
% With Each hypergraph corresponding to each modality;
% 1) MRI; 2) PET; 3) CSF; 
% Then all the hyperedges are combined together;
% Finally, use hypergraph regularized transductive classificaiton.
clc
clear

load ADNI1_CompleteData.mat;
%% AD vs. NC classification
iA=compData( find(compLabel~=1) , : ) ;
iA(43,188)=iA(42,188);iA(43,190)=iA(42,190);
Data=featureNormalize( iA );
clear iA;

Label=compLabel( find(compLabel~=1 ), 1 );
Label(Label==0)=1;  % AD-2, NC-1
iN=size(Label,1);

class_num=length(unique(Label));
fold_num=5;
partitionNum=1;

%% Cross-validataion

for ggg=1:partitionNum  
    
  result_HGL=zeros(fold_num,7);
  result_SVM=zeros(fold_num,7);
  subgroup=randomPartition(Data,Label,class_num,fold_num); 
  
  result_HGL_labels=[]; result_SVM_labels=[];
  for subgroupNum=1:1%fold_num
            
      % Prepare data: one fold as test data and the others as training data
      train_num=1;
      test_num=1;
      for j=1:iN   %  
          if(subgroup(j,1)==subgroupNum)
              teData(test_num,:)=subgroup(j,3:end);
              teLab(test_num,:)=subgroup(j,2);
              test_num=test_num+1;
          else
              trData(train_num,:)=subgroup(j,3:end);
              trLab(train_num,:)=subgroup(j,2);
              train_num=train_num+1;
          end
      end    
    
    %% Hypergraph Regularized Transductive Classification
    % To construct hypergraphs in each modality spacem, and combine all hyperedges together
    % and to perform hypergraph regularized transductive classificaiton
    addpath(genpath('HGL_EW'));
    
    newData=[trData;teData];
    trLab(trLab==1)=-1; trLab(trLab==2)=1;
    teLab(teLab==1)=-1; teLab(teLab==2)=1;    
    newLabel=[trLab; zeros(size(teLab,1),1)];
    
    mDist{1,1} = dist( (newData(:,1:93))' );
    mDist{2,1} = dist( (newData(:,94:186))' );
    mDist{3,1} = dist( (newData(:,187:end))' );
    mPara.mDist=mDist;
    
  % To compute the classificaiton results
    lambdaPool = 0.1; %[0.001; 0.01;0.1; 1; 10; 50; 100; 500; 1000; 10000];
    starPool = [3; 5; 7; 9; 11; 15; 20];
    proRatioPool = 0.5; %[0.05; 0.1; 1];
    
    iAcc=0;
    for ii=1:size(lambdaPool,1)            
        mPara.lambda = lambdaPool(ii,1); 
        % The parameter on empirical loss in hypergraph learning   
        for jj=1:size(lambdaPool,1) 
            mPara.mu = lambdaPool(jj,1);
            % The parameter on the hyperedge weight in hypergraph learning 
          for pp=1:size(starPool,1)
            mPara.mStarExp=starPool(pp,1);            
            for qq=1:size(proRatioPool,1)
                mPara.mProb=proRatioPool(qq,1);  % ratio for bandwidth        
            
            [F, H, W, initialW] = HG_Classify (mPara,newLabel);    
            predictTrLab=F(size(trLab,1),1);    
            predictTeLab=F(size(trLab,1)+1:end,1);    
            predictTeLab(predictTeLab>=0)=1;    
            predictTeLab(predictTeLab<0)=-1;    
            [xx,yy,T,AUC]=perfcurve(teLab,predictTeLab,1);    
            [ACC,SEN,SPE,BAC,PPV,NPV]=lmx_SenSpeAcc(predictTeLab,teLab);   
          
            end  % end for proRatio
          end % end for starPool   
      
        end  % end for mu
    end  % end for lambda
    
          
  end % subgroupNum 10-fold cross validation
  
end  % Partition Number

% save result_CompleteModal_ADNC.mat
aa=1;

end